-------------------------------------------------------------------------------
-- @module global

-------------------------------
-- the tt module
-- @field [parent=#global] tt#tt tt preloaded module

return nil