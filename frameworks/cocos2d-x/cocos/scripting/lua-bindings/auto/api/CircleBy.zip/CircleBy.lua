
--------------------------------
-- @module CircleBy
-- @extend ActionInterval
-- @parent_module tt

--------------------------------
-- @function [parent=#CircleBy] startWithTarget 
-- @param self
-- @param #cc.Node node
        
--------------------------------
-- @function [parent=#CircleBy] init 
-- @param self
-- @param #float float
-- @param #vec2_table vec2
-- @param #float float
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @function [parent=#CircleBy] clone 
-- @param self
-- @return CircleBy#CircleBy ret (return value: CircleBy)
        
--------------------------------
-- @function [parent=#CircleBy] update 
-- @param self
-- @param #float float
        
--------------------------------
-- @function [parent=#CircleBy] reverse 
-- @param self
-- @return CircleBy#CircleBy ret (return value: CircleBy)
        
--------------------------------
-- @function [parent=#CircleBy] create 
-- @param self
-- @param #float float
-- @param #vec2_table vec2
-- @param #float float
-- @return CircleBy#CircleBy ret (return value: CircleBy)
        
return nil
